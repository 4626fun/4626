// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

/**
 * @title IAgentTaxAccountingAdapter (suggested, audited rewrite)
 * @notice Callback surface for AgentTokenV4 `taxAccountingAdapter` cooperation (V3).
 * @dev Addresses audit findings C-1, M-6.
 */
interface IAgentTaxAccountingAdapter {
    event AgentRevenueAccrued(
        address indexed agentToken,
        address indexed vault,
        uint256 buyTaxAmount,
        uint256 sellTaxAmount,
        uint64 epoch
    );

    /**
     * @notice Buy-tax accounting callback.
     * @dev C-1: MUST revert unless `msg.sender == agentToken()`. `amount` is the
     *      tax reported by the (trusted) token; if the adapter custodies the tax
     *      token it SHOULD instead reconcile against a measured balance delta.
     */
    function onBuyTax(address buyer, uint256 amount) external;

    /// @dev C-1: MUST revert unless `msg.sender == agentToken()`. See onBuyTax.
    function onSellTax(address seller, uint256 amount) external;

    function agentToken() external view returns (address);
    function vault() external view returns (address);

    // ── Epoch surface (M-6) ──────────────────────────────────────────────
    /// @notice Current accounting epoch used in {AgentRevenueAccrued}.
    function currentEpoch() external view returns (uint64);
    /// @notice Accrued buy/sell tax for a given epoch.
    function accruedRevenue(uint64 epoch) external view returns (uint256 buy, uint256 sell);
}
