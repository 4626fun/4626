// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

/**
 * @title IAgentGaugeController (suggested, audited rewrite)
 * @author 0xakita.eth
 * @notice Interface for configuring agent gauge controllers.
 * @dev Addresses audit findings C-2, H-1, M-1, M-2. Every privileged setter
 *      documents its required caller, has a matching getter, and emits an event.
 */
interface IAgentGaugeController {
    // ── Events (M-1) ─────────────────────────────────────────────────────
    event VaultUpdated(address indexed previous, address indexed next);
    event WrapperUpdated(address indexed previous, address indexed next);
    event AgentTokenUpdated(address indexed previous, address indexed next);
    event LotteryManagerUpdated(address indexed previous, address indexed next);
    event OracleUpdated(address indexed previous, address indexed next);
    event OwnershipTransferStarted(address indexed previousOwner, address indexed newOwner);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    /// @dev C-2: emitted only after the transfer of `amount` of `token` is verified.
    event FeesReceived(address indexed token, address indexed from, uint256 amount);

    // ── Config getters (M-2) ─────────────────────────────────────────────
    function vault() external view returns (address);
    function wrapper() external view returns (address);
    function agentToken() external view returns (address);
    function lotteryManager() external view returns (address);
    function oracle() external view returns (address);

    // ── Owner-gated setters ──────────────────────────────────────────────
    /// @dev MUST revert unless `msg.sender == owner()`; MUST reject the zero address.
    function setVault(address _vault) external;
    function setWrapper(address _wrapper) external;
    function setAgentToken(address _agentToken) external;
    function setLotteryManager(address _lotteryManager) external;
    function setOracle(address _oracle) external;

    // ── Two-step ownership (H-1) ─────────────────────────────────────────
    function owner() external view returns (address);
    function pendingOwner() external view returns (address);
    /// @dev Sets `pendingOwner`; does NOT transfer control until acceptOwnership().
    function transferOwnership(address newOwner) external;
    /// @dev MUST revert unless `msg.sender == pendingOwner()`.
    function acceptOwnership() external;

    // ── Fees (C-2) ───────────────────────────────────────────────────────
    /**
     * @notice Accrue protocol fees.
     * @dev Value MUST be self-verifying: the implementation pulls `amount` of a
     *      known fee token via transferFrom (or measures a balance delta) so the
     *      reported `amount` cannot be spoofed. Caller SHOULD be restricted to the
     *      authorized fee source. Emits {FeesReceived}.
     */
    function receiveFees(uint256 amount) external;
}
