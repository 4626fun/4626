// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

/**
 * @title IAgentTokenV4 (suggested, audited rewrite)
 * @notice Minimal read/write surface for AgentTokenV4-style tokens (ABI-only integration).
 * @dev Addresses audit findings M-1, M-2, M-5, L-1, L-2, L-3, I-1.
 *      No upstream implementation dependency. Validate against mock + optional mainnet fork.
 */
interface IAgentTokenV4 {
    // ── Events (M-1) ─────────────────────────────────────────────────────
    event ProjectTaxRecipientUpdated(address indexed previous, address indexed next);
    event TaxAccountingAdapterUpdated(address indexed previous, address indexed next);
    event TaxDistributed(uint256 amountIn, uint256 amountOut);

    // ── Discovery / routing ──────────────────────────────────────────────
    function owner() external view returns (address);            // M-2
    function vault() external view returns (address);
    function projectTaxRecipient() external view returns (address);
    function taxAccountingAdapter() external view returns (address);

    // ── LP / pair surface ────────────────────────────────────────────────
    function pairToken() external view returns (address);
    function uniswapV2Pair() external view returns (address);
    function liquidityPools(uint256 index) external view returns (address);
    /// @notice L-1: enumeration length so callers need not probe-and-catch.
    function liquidityPoolsLength() external view returns (uint256);
    /**
     * @notice Authoritative pool predicate (L-2).
     * @dev Invariant: isLiquidityPool(uniswapV2Pair()) == true.
     */
    function isLiquidityPool(address account) external view returns (bool);

    // ── Tax configuration ────────────────────────────────────────────────
    /// @dev Invariant (L-3): buyTaxBps() <= 10000 (i.e. <= 100%).
    function buyTaxBps() external view returns (uint16);
    /// @dev Invariant (L-3): sellTaxBps() <= 10000.
    function sellTaxBps() external view returns (uint16);
    function projectTaxPendingSwap() external view returns (uint256);

    // ── Owner-gated setters (cooperation path) ───────────────────────────
    /// @dev MUST revert unless `msg.sender == owner()`. Emits the paired event.
    function setProjectTaxRecipient(address recipient) external;
    function setTaxAccountingAdapter(address adapter) external;

    // ── Tax distribution (keeper / owner) ────────────────────────────────
    /**
     * @notice Swap & distribute accumulated project tax.
     * @dev M-5: slippage/deadline guarded to prevent sandwiching. Caller SHOULD
     *      be restricted to keeper/owner. Emits {TaxDistributed}.
     */
    function distributeTaxTokens(uint256 minOut, uint256 deadline) external;
}
