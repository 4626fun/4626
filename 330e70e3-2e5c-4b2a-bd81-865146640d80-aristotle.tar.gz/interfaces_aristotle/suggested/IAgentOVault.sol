// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

/**
 * @title IAgentOVault (suggested, audited rewrite)
 * @author 0xakita.eth
 * @notice Minimal vault interface for registry and helper wiring.
 * @dev Addresses audit findings H-1, H-2, H-3, M-1, M-2, M-3, M-4.
 */
interface IAgentOVault {
    // ── Events (M-1) ─────────────────────────────────────────────────────
    event Deposit(address indexed caller, address indexed receiver, uint256 assets, uint256 shares);
    event GaugeControllerUpdated(address indexed previous, address indexed next);
    event CcaLaunchArmUpdated(address indexed previous, address indexed next);
    event WhitelistUpdated(address indexed account, bool status);
    event ProtocolRescueUpdated(address indexed previous, address indexed next);
    event ModulesLocked(address core, address strategies, address admin);
    event OwnershipTransferStarted(address indexed previousOwner, address indexed newOwner);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    // ── ERC4626-style surface (M-3) ──────────────────────────────────────
    /// @notice Underlying asset integrators must approve before deposit.
    function asset() external view returns (address);
    function totalAssets() external view returns (uint256);
    function convertToAssets(uint256 shares) external view returns (uint256);
    function convertToShares(uint256 assets) external view returns (uint256);

    /**
     * @notice Deposit `assets`, minting shares to `receiver`.
     * @dev H-2: slippage-guarded. MUST revert if minted shares < `minShares`.
     *      Implementation MUST mitigate the empty-vault inflation attack.
     */
    function deposit(uint256 assets, address receiver, uint256 minShares) external returns (uint256 shares);

    // ── Module wiring (M-4) ──────────────────────────────────────────────
    /// @dev Write-once. MUST revert if `modulesLocked()` is already true. Emits {ModulesLocked}.
    function setModulesOnce(address coreModule, address strategiesModule, address adminModule) external;
    function modulesLocked() external view returns (bool);
    function coreModule() external view returns (address);
    function strategiesModule() external view returns (address);
    function adminModule() external view returns (address);

    // ── Config getters + setters (M-2) ───────────────────────────────────
    function gaugeController() external view returns (address);
    function ccaLaunchArm() external view returns (address);
    function isWhitelisted(address account) external view returns (bool);
    /// @dev All setters: MUST revert unless `msg.sender == owner()`.
    function setGaugeController(address _controller) external;
    function setCcaLaunchArm(address _ccaLaunchArm) external;
    function setWhitelist(address _account, bool _status) external;

    // ── Protocol rescue (H-3) ────────────────────────────────────────────
    function protocolRescue() external view returns (address);
    /**
     * @dev High-privilege role. SHOULD be timelocked/two-step. Emits
     *      {ProtocolRescueUpdated}. The rescue role MUST NOT be able to touch
     *      user principal.
     */
    function setProtocolRescue(address rescue) external;

    // ── Two-step ownership (H-1) ─────────────────────────────────────────
    function owner() external view returns (address);
    function pendingOwner() external view returns (address);
    function transferOwnership(address newOwner) external;
    function acceptOwnership() external;
}
