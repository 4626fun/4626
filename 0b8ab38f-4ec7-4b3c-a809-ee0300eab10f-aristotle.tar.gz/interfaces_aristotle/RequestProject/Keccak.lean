import Mathlib

/-!
# A verified `keccak-256` and Solidity ABI function-selector engine

This module provides an executable implementation of the `keccak-256` hash
(the exact variant used by the EVM / Solidity, i.e. Keccak padding `pad10*1`
with domain byte `0x01`, rate `r = 1088` bits) together with the Solidity ABI
function selector `bytes4(keccak256(canonical_signature))`.

The implementation is *validated* below against published test vectors and
against several well-known canonical function selectors (OpenZeppelin
`Ownable.transferOwnership`, ERC-4626 `deposit` / `convertToAssets`). These
validation lemmas certify that `selector` really is the Solidity selector, so
that the ABI-consistency theorems in `RequestProject.Audit` are meaningful.

All computational facts are discharged with `native_decide` (relying only on the
compiler-reduction axiom `Lean.ofReduceBool`).
-/

namespace ABIKeccak

/-- Rotate a 64-bit word left by `n` bits (`0 ≤ n < 64`). -/
def rotl (x : UInt64) (n : Nat) : UInt64 :=
  if n == 0 then x else (x <<< (UInt64.ofNat n)) ||| (x >>> (UInt64.ofNat (64 - n)))

/-- The 24 Keccak-f round constants. -/
def RC : Array UInt64 := #[
  0x0000000000000001, 0x0000000000008082, 0x800000000000808A, 0x8000000080008000,
  0x000000000000808B, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
  0x000000000000008A, 0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
  0x000000008000808B, 0x800000000000008B, 0x8000000000008089, 0x8000000000008003,
  0x8000000000008002, 0x8000000000000080, 0x000000000000800A, 0x800000008000000A,
  0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008]

/-- The Keccak `ρ` rotation offsets, indexed by lane `x + 5*y`. -/
def rho : Array Nat := #[
  0,1,62,28,27, 36,44,6,55,20, 3,10,43,25,39, 41,45,15,21,8, 18,2,61,56,14]

@[inline] def g (a : Array UInt64) (i : Nat) : UInt64 := a.getD i 0

/-- The `θ` step of Keccak-f. -/
def theta (a : Array UInt64) : Array UInt64 := Id.run do
  let mut c : Array UInt64 := Array.replicate 5 0
  for x in [0:5] do
    c := c.set! x (g a x ^^^ g a (x+5) ^^^ g a (x+10) ^^^ g a (x+15) ^^^ g a (x+20))
  let mut d : Array UInt64 := Array.replicate 5 0
  for x in [0:5] do
    d := d.set! x (c.getD ((x+4)%5) 0 ^^^ rotl (c.getD ((x+1)%5) 0) 1)
  let mut r := a
  for x in [0:5] do
    for y in [0:5] do
      r := r.set! (x+5*y) (g r (x+5*y) ^^^ d.getD x 0)
  return r

/-- The combined `ρ` (rotation) and `π` (lane permutation) steps of Keccak-f. -/
def rhopi (a : Array UInt64) : Array UInt64 := Id.run do
  let mut b : Array UInt64 := Array.replicate 25 0
  for x in [0:5] do
    for y in [0:5] do
      b := b.set! (y+5*((2*x+3*y)%5)) (rotl (g a (x+5*y)) (rho.getD (x+5*y) 0))
  return b

/-- The `χ` step of Keccak-f. -/
def chi (a : Array UInt64) : Array UInt64 := Id.run do
  let mut r := a
  for y in [0:5] do
    for x in [0:5] do
      r := r.set! (x+5*y) (g a (x+5*y) ^^^ ((~~~ g a ((x+1)%5+5*y)) &&& g a ((x+2)%5+5*y)))
  return r

/-- The full 24-round Keccak-f[1600] permutation. -/
def keccakF (a0 : Array UInt64) : Array UInt64 := Id.run do
  let mut a := a0
  for round in [0:24] do
    a := theta a
    a := rhopi a
    a := chi a
    a := a.set! 0 (g a 0 ^^^ RC.getD round 0)
  return a

/-- Keccak padding (`pad10*1`) to a multiple of the 136-byte rate,
using the EVM domain byte `0x01`. -/
def pad (msg : Array UInt8) : Array UInt8 := Id.run do
  let mut m := msg
  let r := 136
  let padlen := r - (m.size % r)
  if padlen == 1 then
    m := m.push 0x81
  else
    m := m.push 0x01
    for _ in [0:padlen-2] do
      m := m.push 0x00
    m := m.push 0x80
  return m

/-- Read 8 little-endian bytes at offset `off` as a 64-bit lane. -/
def bytesToLane (m : Array UInt8) (off : Nat) : UInt64 := Id.run do
  let mut v : UInt64 := 0
  for j in [0:8] do
    v := v ||| ((UInt64.ofNat (m.getD (off+j) 0).toNat) <<< (UInt64.ofNat (8*j)))
  return v

/-- `keccak-256` as used by the EVM: returns the 32-byte digest. -/
def keccak256 (msg : Array UInt8) : Array UInt8 := Id.run do
  let m := pad msg
  let mut s : Array UInt64 := Array.replicate 25 0
  let r := 136
  let nblocks := m.size / r
  for blk in [0:nblocks] do
    for i in [0:17] do
      s := s.set! i (g s i ^^^ bytesToLane m (blk*r + i*8))
    s := keccakF s
  let mut out : Array UInt8 := #[]
  for i in [0:4] do
    let lane := g s i
    for j in [0:8] do
      out := out.push (UInt8.ofNat ((lane >>> (UInt64.ofNat (8*j))).toNat % 256))
  return out

/-- ASCII/UTF-8 encoding of a string as a byte array. -/
def strBytes (s : String) : Array UInt8 := (s.toUTF8).foldl (fun a b => a.push b) #[]

/-- The Solidity ABI function selector: the first four bytes of
`keccak256(canonical_signature)`, packed big-endian into a `UInt32`. -/
def selector (sig : String) : UInt32 := Id.run do
  let h := keccak256 (strBytes sig)
  let mut v : UInt32 := 0
  for i in [0:4] do
    v := (v <<< 8) ||| (UInt32.ofNat (h.getD i 0).toNat)
  return v

/-- Lowercase hex rendering of a byte array (no `0x` prefix). -/
def toHex (a : Array UInt8) : String :=
  a.foldl (fun acc b =>
    acc ++ String.ofList (Nat.toDigits 16 (b.toNat/16))
        ++ String.ofList (Nat.toDigits 16 (b.toNat%16))) ""

/-! ## Validation of the hash against published test vectors -/

/-- `keccak256("")` matches the published digest. -/
theorem keccak_empty :
    toHex (keccak256 (strBytes "")) =
      "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470" := by
  native_decide

/-- `keccak256("abc")` matches the published digest. -/
theorem keccak_abc :
    toHex (keccak256 (strBytes "abc")) =
      "4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45" := by
  native_decide

/-! ## Validation of the selector against canonical well-known selectors -/

/-- OpenZeppelin `Ownable.transferOwnership(address)` selector. -/
theorem sel_transferOwnership : selector "transferOwnership(address)" = 0xf2fde38b := by
  native_decide

/-- ERC-4626 `deposit(uint256,address)` selector. -/
theorem sel_deposit : selector "deposit(uint256,address)" = 0x6e553f65 := by
  native_decide

/-- ERC-4626 `convertToAssets(uint256)` selector. -/
theorem sel_convertToAssets : selector "convertToAssets(uint256)" = 0x07a2d13a := by
  native_decide

end ABIKeccak
