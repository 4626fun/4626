import RequestProject.Keccak

/-!
# ABI-consistency audit of the creator interfaces

This module models the external function surface of the two creator interfaces

* `ICreatorGaugeController.sol`
* `ICreatorOVault.sol`

as the lists of their *canonical* Solidity function signatures, and proves the
core ABI-consistency property: **no function-selector collisions**.

In Solidity a call is dispatched on `bytes4(keccak256(canonical_signature))`.
Two *distinct* signatures that share a selector make the two functions
indistinguishable to the ABI dispatcher — a "dangerous assumption / ABI
consistency" bug. We prove this cannot happen here.

All facts are decided by the verified `ABIKeccak.selector` engine from
`RequestProject.Keccak` via `native_decide`.
-/

namespace CreatorAudit

open ABIKeccak

/-- Canonical function signatures of `ICreatorGaugeController`. -/
def gauge : List String :=
  [ "setVault(address)",
    "setWrapper(address)",
    "setCreatorCoin(address)",
    "setLotteryManager(address)",
    "setOracle(address)",
    "transferOwnership(address)",
    "receiveFees(uint256)" ]

/-- Canonical function signatures of `ICreatorOVault`. -/
def vault : List String :=
  [ "deposit(uint256,address)",
    "setModulesOnce(address,address,address)",
    "setGaugeController(address)",
    "setCcaLaunchArm(address)",
    "setWhitelist(address,bool)",
    "setProtocolRescue(address)",
    "transferOwnership(address)",
    "convertToAssets(uint256)" ]

/-! ## Recorded selector values (documentation-grade certificates) -/

theorem sel_setVault          : selector "setVault(address)"                      = 0x6817031b := by native_decide
theorem sel_setWrapper        : selector "setWrapper(address)"                    = 0xc2167d93 := by native_decide
theorem sel_setCreatorCoin    : selector "setCreatorCoin(address)"                = 0x62ca8bb3 := by native_decide
theorem sel_setLotteryManager : selector "setLotteryManager(address)"            = 0xb98346f2 := by native_decide
theorem sel_setOracle         : selector "setOracle(address)"                     = 0x7adbf973 := by native_decide
theorem sel_receiveFees       : selector "receiveFees(uint256)"                   = 0x0420592e := by native_decide
theorem sel_setModulesOnce    : selector "setModulesOnce(address,address,address)"= 0x402e1c9c := by native_decide
theorem sel_setGaugeController : selector "setGaugeController(address)"            = 0x0091d2b8 := by native_decide
theorem sel_setCcaLaunchArm   : selector "setCcaLaunchArm(address)"               = 0xc98e26d9 := by native_decide
theorem sel_setWhitelist      : selector "setWhitelist(address,bool)"             = 0x53d6fd59 := by native_decide
theorem sel_setProtocolRescue : selector "setProtocolRescue(address)"             = 0xa6bb16c6 := by native_decide

/-! ## Intra-interface collision freedom -/

/-- All selectors of `ICreatorGaugeController` are pairwise distinct: the
gauge-controller ABI dispatcher is unambiguous. -/
theorem gauge_selectors_nodup : (gauge.map selector).Nodup := by native_decide

/-- All selectors of `ICreatorOVault` are pairwise distinct: the vault ABI
dispatcher is unambiguous. -/
theorem vault_selectors_nodup : (vault.map selector).Nodup := by native_decide

/-! ## Selector is injective on each interface -/

/-- On the gauge interface, equal selectors force equal signatures. -/
theorem gauge_selector_injective :
    ∀ s₁ ∈ gauge, ∀ s₂ ∈ gauge, selector s₁ = selector s₂ → s₁ = s₂ := by
  native_decide

/-- On the vault interface, equal selectors force equal signatures. -/
theorem vault_selector_injective :
    ∀ s₁ ∈ vault, ∀ s₂ ∈ vault, selector s₁ = selector s₂ → s₁ = s₂ := by
  native_decide

/-! ## Cross-interface consistency -/

/-- The **only** selector shared between the two interfaces is the one of the
identical signature `transferOwnership(address)`. Equivalently: any
cross-interface selector clash is between *identical* signatures, never between
two different functions. This is the key safety property should the interfaces
ever be composed behind one dispatcher (proxy / diamond / multi-inheritance). -/
theorem cross_selector_injective :
    ∀ s₁ ∈ gauge, ∀ s₂ ∈ vault, selector s₁ = selector s₂ → s₁ = s₂ := by
  native_decide

/-- Combined-dispatcher safety: after removing duplicate signatures, the union
of both interfaces has pairwise-distinct selectors. A single contract (or proxy)
implementing both interfaces has a well-defined, collision-free ABI. -/
theorem combined_selectors_nodup :
    (((gauge ++ vault).dedup).map selector).Nodup := by native_decide

/-- Global injectivity: over both interfaces, distinct signatures always have
distinct selectors. -/
theorem all_selector_injective :
    ∀ s₁ ∈ (gauge ++ vault), ∀ s₂ ∈ (gauge ++ vault),
      selector s₁ = selector s₂ → s₁ = s₂ := by
  native_decide

/-! ## ABI compatibility certificates for the standard-shaped functions

These record that the vault's `deposit` / `convertToAssets` and both interfaces'
`transferOwnership` selectors are *exactly* the canonical ERC-4626 / OZ-Ownable
selectors, so standard tooling interoperates with them as intended. -/

/-- The shared ownership entrypoint uses the canonical OZ `Ownable` selector. -/
theorem transferOwnership_is_canonical :
    selector "transferOwnership(address)" = 0xf2fde38b := by native_decide

/-- The vault `deposit` selector is the canonical ERC-4626 selector. -/
theorem deposit_is_erc4626 :
    selector "deposit(uint256,address)" = 0x6e553f65 := by native_decide

/-- The vault `convertToAssets` selector is the canonical ERC-4626 selector. -/
theorem convertToAssets_is_erc4626 :
    selector "convertToAssets(uint256)" = 0x07a2d13a := by native_decide

end CreatorAudit
