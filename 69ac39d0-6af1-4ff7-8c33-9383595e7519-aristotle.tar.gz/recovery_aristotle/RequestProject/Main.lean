import Mathlib

open scoped BigOperators
open scoped Real
open scoped Nat
open scoped Classical
open scoped Pointwise

set_option maxHeartbeats 8000000
set_option maxRecDepth 4000
set_option synthInstance.maxHeartbeats 20000
set_option synthInstance.maxSize 128

set_option relaxedAutoImplicit false
set_option autoImplicit false

set_option pp.fullNames true
set_option pp.structureInstances true
set_option pp.coercions.types true
set_option pp.funBinderTypes true
set_option pp.letVarTypes true
set_option pp.piBinderTypes true

set_option grind.warning false

/-!
# Formal re-audit: pending-claims lock on vault rotation (`OVaultRecoveryEscrow`)

This file formalizes the vault-rotation state machine of `OVaultRecoveryEscrow.sol`
and re-verifies the security fix that enforces the **pending-claims lock at both the
queue stage (`setVault`) and the execute stage (`executeVaultUpdate`)**.

Rationale of the fix.  The escrow custodies recovered funds; `totalUnclaimedRecovery`
tracks funds that have been notified but not yet claimed.  Only the *current* `vault`
may `notifyRecovery` / `claimRecovery`.  Rotating the vault while unclaimed funds
remain would hand control of those funds to a different vault, so rotation must be
blocked whenever `totalUnclaimedRecovery > 0`.

* Checking the lock only at the **queue** stage is insufficient: an operator could
  queue while clean, then `notifyRecovery` during the timelock window, then execute
  the rotation with pending claims outstanding.
* Checking at the **execute** stage is the load-bearing guarantee; checking at the
  **queue** stage adds an early revert (defense-in-depth).

The model uses `Nat` for addresses (`0` = `address(0)`) and abstracts the per-epoch
recovery accounting by the aggregate `totalUnclaimedRecovery` counter, which is the
only quantity the lock inspects.  Solidity 0.8 checked arithmetic is modeled by
reverting (`none`) on the subtraction underflow in `claimRecovery`.

The sibling contract `OVaultImpairmentClaims.sol` exposes the same
`setVault` / `executeVaultUpdate` timelock but intentionally carries **no**
pending-claims lock, because it custodies no recovery funds (it only mints
non-transferable ERC-1155 claim tokens); there is nothing to lock there.
-/

namespace OVaultRecoveryEscrow

/-- `VAULT_UPDATE_TIMELOCK = 1 days`, in seconds. -/
def TIMELOCK : Nat := 86400

/-- Abstract on-chain state relevant to vault rotation. -/
structure State where
  /-- Current vault address (`0` = unset / `address(0)`). -/
  vault : Nat
  /-- Queued next vault address. -/
  pendingVault : Nat
  /-- Timestamp after which a queued rotation may execute (`0` = none queued). -/
  pendingVaultAt : Nat
  /-- Aggregate notified-but-unclaimed recovery amount. -/
  totalUnclaimedRecovery : Nat
deriving DecidableEq, Repr

/-- Fresh deployment: no vault, nothing queued, nothing unclaimed. -/
def init : State := ⟨0, 0, 0, 0⟩

/-- `setVault(vault_)` under `onlyOwner`.  `none` = revert. -/
def setVault (s : State) (vault_ : Nat) (now : Nat) : Option State :=
  if vault_ = 0 then none                              -- ZeroAddress
  else if s.totalUnclaimedRecovery > 0 then none       -- PendingRecoveryClaims (queue-stage lock)
  else if s.vault = 0 then
    -- first-time set: no timelock
    some { s with vault := vault_ }
  else
    -- queue a rotation behind the timelock
    some { s with pendingVault := vault_, pendingVaultAt := now + TIMELOCK }

/-- `executeVaultUpdate()` under `onlyOwner`.  `none` = revert. -/
def executeVaultUpdate (s : State) (now : Nat) : Option State :=
  if s.pendingVaultAt = 0 then none                    -- NoPendingVault
  else if now < s.pendingVaultAt then none             -- VaultUpdateTimelockActive
  else if s.totalUnclaimedRecovery > 0 then none       -- PendingRecoveryClaims (execute-stage lock)
  else some { s with vault := s.pendingVault, pendingVault := 0, pendingVaultAt := 0 }

/-- `notifyRecovery(asset, epochId, amount)`: only the current vault; increases the
    unclaimed counter by the received amount. -/
def notifyRecovery (s : State) (caller : Nat) (amount : Nat) : Option State :=
  if caller ≠ s.vault then none                        -- Unauthorized
  else some { s with totalUnclaimedRecovery := s.totalUnclaimedRecovery + amount }

/-- `claimRecovery(asset, epochId, receiver, amount)`: only the current vault;
    decreases the unclaimed counter, reverting on underflow (checked arithmetic). -/
def claimRecovery (s : State) (caller : Nat) (amount : Nat) : Option State :=
  if caller ≠ s.vault then none                        -- Unauthorized
  else if amount > s.totalUnclaimedRecovery then none  -- checked subtraction underflow
  else some { s with totalUnclaimedRecovery := s.totalUnclaimedRecovery - amount }

/-! ## Core lock guarantees -/

/-- **Execute-stage lock.**  A rotation can only *execute* when no recovery is
    unclaimed. -/
theorem executeVaultUpdate_requires_zero_unclaimed
    (s s' : State) (now : Nat)
    (h : executeVaultUpdate s now = some s') :
    s.totalUnclaimedRecovery = 0 := by
  unfold executeVaultUpdate at h
  split_ifs at h
  all_goals omega

/-- **Queue-stage lock.**  Any successful `setVault` (whether first-time set or a
    queued rotation) requires no recovery to be unclaimed. -/
theorem setVault_requires_zero_unclaimed
    (s s' : State) (vault_ now : Nat)
    (h : setVault s vault_ now = some s') :
    s.totalUnclaimedRecovery = 0 := by
  unfold setVault at h
  split_ifs at h
  all_goals omega

/-- Functional correctness of a successful execute: the new vault is exactly the
    previously queued `pendingVault`, and the pending slots are cleared. -/
theorem executeVaultUpdate_effect
    (s s' : State) (now : Nat)
    (h : executeVaultUpdate s now = some s') :
    s'.vault = s.pendingVault ∧ s'.pendingVault = 0 ∧ s'.pendingVaultAt = 0 := by
  unfold executeVaultUpdate at h
  split_ifs at h
  all_goals simp_all
  obtain ⟨rfl⟩ := h
  exact ⟨rfl, rfl, rfl⟩

/-- A successful execute also requires the timelock to have elapsed and a rotation
    to have been queued. -/
theorem executeVaultUpdate_requires_timelock
    (s s' : State) (now : Nat)
    (h : executeVaultUpdate s now = some s') :
    s.pendingVaultAt ≠ 0 ∧ now ≥ s.pendingVaultAt := by
  unfold executeVaultUpdate at h
  split_ifs at h
  all_goals omega

/-! ## Why the lock is needed at *both* stages

The following concrete trace shows that queuing while clean does not make the
rotation safe: a `notifyRecovery` during the timelock window leaves unclaimed funds,
and the **execute-stage** lock then blocks the rotation.  This is exactly the gap
that a queue-only check would miss. -/

/-- Trace: deploy, set vault `1`, queue rotation to vault `2` (clean), then vault `1`
    notifies a recovery of `5`.  The resulting pre-execute state. -/
def scenarioState : Option State :=
  (setVault init 1 0).bind fun s1 =>
  (setVault s1 2 100).bind fun s2 =>
  notifyRecovery s2 1 5

/-- After the post-queue notify, the queued rotation is present but unclaimed
    funds are outstanding, and `executeVaultUpdate` reverts even though the
    timelock has fully elapsed. -/
theorem post_queue_notify_blocks_execute :
    ∃ s : State,
      scenarioState = some s ∧
      s.pendingVault = 2 ∧
      s.totalUnclaimedRecovery = 5 ∧
      executeVaultUpdate s (100 + TIMELOCK) = none := by
  refine ⟨_, rfl, ?_, ?_, ?_⟩ <;> decide

/-- Sanity check that the trace is otherwise valid: had no recovery been notified,
    the very same queued rotation *would* execute successfully once the timelock
    elapses (rotating the vault to `2`).  So the revert above is caused solely by
    the pending-claims lock, not by any other guard. -/
theorem clean_rotation_executes :
    ∃ s s' : State,
      (setVault init 1 0).bind (fun s1 => setVault s1 2 100) = some s ∧
      executeVaultUpdate s (100 + TIMELOCK) = some s' ∧
      s'.vault = 2 := by
  exact ⟨_, _, rfl, rfl, rfl⟩

end OVaultRecoveryEscrow
