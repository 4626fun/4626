// SPDX-License-Identifier: MIT
pragma solidity ^0.8.22;

/**
 * @title INonfungiblePositionManager
 * @author Uniswap Labs
 * @notice Interface for Uniswap V3 position manager minting.
 * @dev Used by LP strategy deployments.
 */
interface INonfungiblePositionManager {
    struct MintParams {
        address token0;
        address token1;
        uint24 fee;
        int24 tickLower;
        int24 tickUpper;
        uint256 amount0Desired;
        uint256 amount1Desired;
        uint256 amount0Min;
        uint256 amount1Min;
        address recipient;
        uint256 deadline;
    }

    function mint(MintParams calldata params)
        external
        payable
        returns (uint256 tokenId, uint128 liquidity, uint256 amount0, uint256 amount1);
}
