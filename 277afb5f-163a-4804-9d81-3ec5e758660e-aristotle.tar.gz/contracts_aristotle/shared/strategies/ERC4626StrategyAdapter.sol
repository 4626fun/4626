// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";

import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";

import {IStrategy} from "@4626/shared/interfaces/strategies/IStrategy.sol";
import {IStrategyValuation} from "@4626/shared/interfaces/strategies/IStrategyValuation.sol";

/**
 * @title ERC4626StrategyAdapter
 * @author 0xakita.eth
 * @notice Adapts an ERC-4626 vault to the `IStrategy` interface.
 * @dev Used by lane vaults (CreatorOVault / AgentOVault) to integrate ERC-4626 yield sources.
 */
contract ERC4626StrategyAdapter is IStrategy, IStrategyValuation, Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    // ================================
    // ERRORS
    // ================================

    error OnlyVault();
    error StrategyPaused();
    error InvalidBps();
    error InvalidWindow();
    // FIX: S-C04 — block deposits during active rebalance
    error RebalanceInProgress();
    error InnerDepositFailed();

    // ================================
    // STATE
    // ================================

    /// @notice Lane vault that owns this strategy.
    address public immutable vault;

    /// @notice Underlying asset token (must match the ERC-4626 `asset()`).
    IERC20 public immutable ASSET;

    /// @notice Target ERC-4626 vault (strategy holds shares of this vault).
    IERC4626 public immutable ERC4626_VAULT;

    /// @notice Strategy active flag.
    bool private _isActive;

    /// @notice FIX: S-C04 — rebalance lock prevents deposit-during-rebalance window
    bool public rebalanceActive;

    /// @notice Target % of strategy assets to keep idle (basis points).
    uint256 public idleBufferBps = 1000; // 10% default

    /// @notice Maximum upward valuation move allowed per check window (basis points).
    uint256 public valuationMaxIncreaseBps = 1000; // 10%

    /// @notice Maximum downward valuation move allowed per check window (basis points).
    uint256 public valuationMaxDecreaseBps = 1000; // 10%

    /// @notice Length of one valuation guard window (seconds).
    uint256 public valuationCheckWindow = 30 minutes;

    /// @notice Last trusted assets-per-share snapshot (1e18 scale).
    uint256 public lastValuationAssetsPerShare;

    /// @notice Timestamp when valuation snapshot was last synchronized.
    uint256 public lastValuationTimestamp;

    // ================================
    // EVENTS
    // ================================

    event ValuationGuardUpdated(uint256 maxIncreaseBps, uint256 maxDecreaseBps, uint256 checkWindow);
    event ValuationSnapshotSynced(uint256 assetsPerShare, uint256 timestamp);
    // FIX: S-H03 — surface silent deposit failures during rebalance
    event RebalanceDepositFailed(uint256 amount, bytes reason);

    // ================================
    // MODIFIERS
    // ================================

    modifier onlyVault() {
        if (msg.sender != vault) revert OnlyVault();
        _;
    }

    modifier whenActive() {
        if (!_isActive) revert StrategyPaused();
        _;
    }

    // ================================
    // CONSTRUCTOR
    // ================================

    constructor(address _vault, address _erc4626Vault, address _owner) Ownable(_owner) {
        require(_vault != address(0), "Invalid vault");
        require(_erc4626Vault != address(0), "Invalid ERC4626");

        vault = _vault;
        ERC4626_VAULT = IERC4626(_erc4626Vault);

        address assetAddr = IERC4626(_erc4626Vault).asset();
        require(assetAddr != address(0), "Invalid asset");
        ASSET = IERC20(assetAddr);

        // Safety: prevent wiring a strategy with an asset that doesn't match the outer vault's asset.
        require(IERC4626(_vault).asset() == assetAddr, "Vault/asset mismatch");

        _isActive = true;

        // FIX: M-10 (4626-319) — seed the valuation snapshot immediately on
        // construction. Previously isValuationReady() returned true whenever
        // `lastValuationAssetsPerShare == 0`, which is the initial state until
        // the first strategy operation. During that window deposits routed
        // here were not bounded against the underlying ERC-4626's assets-per-
        // share, leaving an inflation-attack window on any freshly-deployed
        // 4626 vault. Best-effort read on construction closes that window; if
        // the underlying read reverts (empty / uninitialized), the snapshot
        // stays zero and isValuationReady() will still tolerate the absence
        // of exposure (currentAssetsPerShare == 0 branch above).
        _syncValuationSnapshotBestEffort();
    }

    // ================================
    // ISTRATEGY VIEW
    // ================================

    function isActive() external view override returns (bool) {
        return _isActive;
    }

    function asset() external view override returns (address) {
        return address(ASSET);
    }

    /**
     * @notice Strategy valuation health check for ERC-4626 deposit/mint gating.
     * @dev MUST NOT revert. Returns false when the underlying ERC-4626 conversion
     *      reverts for any held shares.
     */
    function isValuationReady() external view override returns (bool) {
        (bool ok, uint256 currentAssetsPerShare) = _readCurrentAssetsPerShare();
        if (!ok) {
            return false;
        }

        // No ERC-4626 share exposure to value.
        if (currentAssetsPerShare == 0) return true;

        uint256 snapshot = lastValuationAssetsPerShare;
        if (snapshot == 0) {
            // FIX: M-10 (4626-319) — returning true here previously let
            // deposits through when there was ERC-4626 share exposure but no
            // trusted snapshot (e.g. constructor read reverted, or an
            // operator manually cleared it). Treat that state as NOT ready.
            // Honest path: the constructor now seeds the snapshot, and every
            // strategy op refreshes it. If we still see snapshot == 0 with
            // non-zero current PPS, something is off and we should fail safe.
            return false;
        }

        return _isWithinValuationBounds(snapshot, currentAssetsPerShare);
    }

    function getTotalAssets() public view override returns (uint256) {
        uint256 idle = ASSET.balanceOf(address(this));
        uint256 sharesHeld = ERC4626_VAULT.balanceOf(address(this));
        if (sharesHeld == 0) return idle;

        // Best-effort conversion (some 4626 implementations can revert in edge cases).
        try ERC4626_VAULT.convertToAssets(sharesHeld) returns (uint256 assetsFromShares) {
            return idle + assetsFromShares;
        } catch {
            return idle;
        }
    }

    // ================================
    // ISTRATEGY OPERATIONS
    // ================================

    function deposit(uint256 amount) external override onlyVault whenActive nonReentrant returns (uint256 deposited) {
        // FIX: S-C04 — prevent deposit during rebalance window
        if (rebalanceActive) revert RebalanceInProgress();
        if (amount == 0) return 0;

        // Pull assets from the vault. `onlyVault` guarantees msg.sender is the trusted vault.
        ASSET.safeTransferFrom(msg.sender, address(this), amount);

        // Maintain idle buffer: deposit only excess idle into the ERC4626 vault.
        uint256 total = getTotalAssets();
        uint256 desiredIdle = (total * idleBufferBps) / 10_000;
        uint256 idle = ASSET.balanceOf(address(this));
        uint256 toDeposit = idle > desiredIdle ? idle - desiredIdle : 0;

        if (toDeposit > 0) {
            ASSET.forceApprove(address(ERC4626_VAULT), toDeposit);
            try ERC4626_VAULT.deposit(toDeposit, address(this)) returns (uint256 shares) {
                shares;
            } catch {
                ASSET.forceApprove(address(ERC4626_VAULT), 0);
                revert InnerDepositFailed();
            }
        }

        deposited = amount;
        _syncValuationSnapshotBestEffort();
        emit StrategyDeposit(msg.sender, amount, deposited);
    }

    function withdraw(uint256 amount) external override onlyVault nonReentrant returns (uint256 withdrawn) {
        if (amount == 0) return 0;

        uint256 remaining = amount;
        uint256 idle = ASSET.balanceOf(address(this));

        // Use idle first.
        if (idle > 0) {
            uint256 takeIdle = idle > remaining ? remaining : idle;
            if (takeIdle > 0) {
                ASSET.safeTransfer(vault, takeIdle);
                withdrawn += takeIdle;
                remaining -= takeIdle;
            }
        }

        if (remaining > 0) {
            uint256 pulled = _withdrawFrom4626BestEffort(remaining);
            if (pulled > 0) {
                ASSET.safeTransfer(vault, pulled);
                withdrawn += pulled;
            }
        }

        _syncValuationSnapshotBestEffort();
        emit StrategyWithdraw(msg.sender, amount, withdrawn);
    }

    function emergencyWithdraw() external override onlyVault nonReentrant returns (uint256 totalWithdrawn) {
        _isActive = false;

        // Best-effort: withdraw as much as possible from the ERC4626 vault.
        uint256 maxAssets = _maxWithdrawBestEffort();
        if (maxAssets > 0) {
            _withdrawFrom4626BestEffort(maxAssets);
        }

        totalWithdrawn = ASSET.balanceOf(address(this));
        if (totalWithdrawn > 0) {
            ASSET.safeTransfer(vault, totalWithdrawn);
        }

        _syncValuationSnapshotBestEffort();
        emit EmergencyWithdraw(vault, totalWithdrawn);
    }

    function harvest() external override onlyVault returns (uint256 profit) {
        // The outer lane vault accounts for gains via totalAssets() deltas in `report()`.
        profit = 0;
        emit StrategyHarvest(profit);
    }

    function rebalance() external override onlyVault {
        // FIX: S-C04 — lock to prevent deposit-during-rebalance window
        rebalanceActive = true;

        // FIX: S-M04 — enforce deadline to prevent stale rebalance txs
        // block.timestamp is used as deadline in sub-calls; rebalance must be mined promptly

        uint256 total = getTotalAssets();
        uint256 desiredIdle = (total * idleBufferBps) / 10_000;
        uint256 idle = ASSET.balanceOf(address(this));

        if (idle > desiredIdle) {
            uint256 toDeposit = idle - desiredIdle;
            if (toDeposit > 0) {
                ASSET.forceApprove(address(ERC4626_VAULT), toDeposit);
                // FIX: S-H03 — log deposit failure instead of silently swallowing
                try ERC4626_VAULT.deposit(toDeposit, address(this)) {} catch (bytes memory reason) {
                    ASSET.forceApprove(address(ERC4626_VAULT), 0);
                    emit RebalanceDepositFailed(toDeposit, reason);
                }
            }
        } else if (idle < desiredIdle) {
            uint256 toPull = desiredIdle - idle;
            if (toPull > 0) {
                _withdrawFrom4626BestEffort(toPull);
            }
        }

        _syncValuationSnapshotBestEffort();
        rebalanceActive = false;
        emit StrategyRebalanced(getTotalAssets());
    }

    // ================================
    // INTERNAL (BEST-EFFORT 4626)
    // ================================

    function _maxWithdrawBestEffort() internal view returns (uint256) {
        try ERC4626_VAULT.maxWithdraw(address(this)) returns (uint256 maxAssets) {
            return maxAssets;
        } catch {
            return 0;
        }
    }

    function _maxRedeemBestEffort() internal view returns (uint256) {
        try ERC4626_VAULT.maxRedeem(address(this)) returns (uint256 maxShares) {
            return maxShares;
        } catch {
            return 0;
        }
    }

    function _withdrawFrom4626BestEffort(uint256 assets) internal returns (uint256 pulled) {
        if (assets == 0) return 0;

        uint256 maxAssets = _maxWithdrawBestEffort();
        uint256 toWithdraw = assets > maxAssets ? maxAssets : assets;
        if (toWithdraw == 0) return 0;

        // Prefer withdraw(assets) to keep accounting in asset terms.
        try ERC4626_VAULT.withdraw(toWithdraw, address(this), address(this)) returns (
            uint256 /* shares */
        ) {
            pulled = toWithdraw;
            return pulled;
        } catch {
            // Fallback: try redeeming the maximum available shares (or previewWithdraw shares).
            uint256 maxShares = _maxRedeemBestEffort();
            if (maxShares == 0) return 0;

            // Attempt to redeem enough shares for the requested assets.
            uint256 sharesToRedeem = maxShares;
            try ERC4626_VAULT.previewWithdraw(toWithdraw) returns (uint256 previewShares) {
                if (previewShares < sharesToRedeem) sharesToRedeem = previewShares;
            } catch {
                // If previewWithdraw reverts, redeem maxShares (best-effort).
            }

            if (sharesToRedeem == 0) return 0;

            try ERC4626_VAULT.redeem(sharesToRedeem, address(this), address(this)) returns (uint256 assetsOut) {
                return assetsOut;
            } catch {
                return 0;
            }
        }
    }

    // ================================
    // ADMIN
    // ================================

    function setActive(bool active) external onlyOwner {
        _isActive = active;
    }

    function setIdleBufferBps(uint256 newBps) external onlyOwner {
        require(newBps <= 10_000, "Invalid bps");
        idleBufferBps = newBps;
    }

    /**
     * @notice Configure valuation guard thresholds and window.
     * @dev The allowed valuation drift scales by full elapsed windows since the last trusted snapshot.
     */
    function setValuationGuard(uint256 maxIncreaseBps, uint256 maxDecreaseBps, uint256 checkWindow) external onlyOwner {
        if (maxIncreaseBps > 10_000 || maxDecreaseBps > 10_000) revert InvalidBps();
        if (checkWindow == 0) revert InvalidWindow();

        valuationMaxIncreaseBps = maxIncreaseBps;
        valuationMaxDecreaseBps = maxDecreaseBps;
        valuationCheckWindow = checkWindow;

        emit ValuationGuardUpdated(maxIncreaseBps, maxDecreaseBps, checkWindow);
    }

    function rescueTokens(address token, uint256 amount, address to) external onlyOwner {
        // Don't allow rescuing the underlying while active.
        if (token == address(ASSET) && _isActive) revert("Cannot rescue asset when active");
        IERC20(token).safeTransfer(to, amount);
    }

    // ================================
    // INTERNAL VALUATION GUARD
    // ================================

    function _readCurrentAssetsPerShare() internal view returns (bool ok, uint256 assetsPerShare) {
        uint256 sharesHeld;
        try ERC4626_VAULT.balanceOf(address(this)) returns (uint256 s) {
            sharesHeld = s;
        } catch {
            return (false, 0);
        }

        if (sharesHeld == 0) return (true, 0);

        uint256 assetsFromShares;
        try ERC4626_VAULT.convertToAssets(sharesHeld) returns (uint256 convertedAssets) {
            assetsFromShares = convertedAssets;
        } catch {
            return (false, 0);
        }

        assetsPerShare = Math.mulDiv(assetsFromShares, 1e18, sharesHeld);
        return (true, assetsPerShare);
    }

    function _allowedBpsForElapsedWindows(uint256 perWindowBps) internal view returns (uint256 allowedBps) {
        if (perWindowBps >= 10_000) return 10_000;

        uint256 elapsed = block.timestamp > lastValuationTimestamp ? block.timestamp - lastValuationTimestamp : 0;
        uint256 windowsElapsed = (elapsed / valuationCheckWindow) + 1; // always allow at least one window
        allowedBps = perWindowBps * windowsElapsed;
        if (allowedBps > 10_000) allowedBps = 10_000;
    }

    function _isWithinValuationBounds(uint256 snapshotPps, uint256 currentPps) internal view returns (bool) {
        if (currentPps >= snapshotPps) {
            uint256 increase = currentPps - snapshotPps;
            uint256 allowedIncrease = Math.mulDiv(snapshotPps, _allowedBpsForElapsedWindows(valuationMaxIncreaseBps), 10_000);
            return increase <= allowedIncrease;
        }

        uint256 decrease = snapshotPps - currentPps;
        uint256 allowedDecrease = Math.mulDiv(snapshotPps, _allowedBpsForElapsedWindows(valuationMaxDecreaseBps), 10_000);
        return decrease <= allowedDecrease;
    }

    function _syncValuationSnapshotBestEffort() internal {
        (bool ok, uint256 currentAssetsPerShare) = _readCurrentAssetsPerShare();
        if (!ok) return;

        lastValuationAssetsPerShare = currentAssetsPerShare;
        lastValuationTimestamp = block.timestamp;
        emit ValuationSnapshotSynced(currentAssetsPerShare, block.timestamp);
    }
}

