// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title ve4626VoterRewardsDistributor
 * @author 0xakita.eth
 * @notice Distributes the "protocol" fee slice to ve4626 voters (ve(3,3) mechanics) — supports creators, agents and future ecosystems
 *
 * @dev Inspired by ve(3,3) systems where voters receive fees/bribes for voting on gauges.
 *      Conceptually similar to bribe/fee-distributor patterns used in b(3,3)/ve(3,3) stacks
 *      (e.g. Hermes V2) but simplified for 4626.
 *
 * How it works:
 * - Each CreatorGaugeController sends its voter slice (currently 21.39% as ShareOFT) to this contract.
 * - The slice is recorded per (epoch, vault).
 * - Users claim pro-rata by their vote weight for that (epoch, vault).
 *
 * Reward token:
 * - We distribute ShareOFT (■) for that vault's trading surface.
 * - Voters may hold ■ directly or unwrap/redeem through the vault stack if desired.
 */

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

interface IVe4626GaugeVotingForRewards {
    function currentEpoch() external view returns (uint256);
    function getVaultWeightAtEpoch(uint256 epoch, address vault) external view returns (uint256);
    function getUserVoteWeightAtEpoch(uint256 epoch, address user, address vault) external view returns (uint256);
}

interface IRegistry4626ForVoterRewards {
    function getTokenForVault(address _vault) external view returns (address);
    function getGaugeControllerForToken(address _token) external view returns (address);
}

contract ve4626VoterRewardsDistributor is Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    // ================================
    // CONSTANTS
    // ================================

    uint256 public constant BPS = 10_000;

    // ================================
    // IMMUTABLES
    // ================================

    IVe4626GaugeVotingForRewards public immutable gaugeVoting;
    IRegistry4626ForVoterRewards public immutable registry;

    // ================================
    // STATE
    // ================================

    /// @notice Where zero-vote epoch rewards are swept after the grace period.
    /// @dev Set by owner; must be non-zero before sweeping is enabled.
    address public protocolTreasury;

    /// @notice Number of weekly epochs to wait before allowing a zero-vote epoch sweep.
    /// @dev 4 epochs ≈ 4 weeks after the epoch ends (sweepable starting epoch+5).
    uint256 public sweepGraceEpochs = 4;

    /// @notice Vault => reward token (vault shares token). Set on first notification.
    mapping(address => address) public vaultRewardToken;

    // FIX: G-10 — store reward token per (epoch, vault) so remapping doesn't break old claims
    mapping(uint256 => mapping(address => address)) public epochRewardToken;

    /// @notice epoch => vault => total rewards (in vault share tokens)
    mapping(uint256 => mapping(address => uint256)) public epochVaultRewards;

    /// @notice epoch => vault => user => claimed?
    mapping(uint256 => mapping(address => mapping(address => bool))) public hasClaimed;

    // FIX: G-18 — extended grace period for stale sweep (non-zero-vote epochs)
    uint256 public staleSweepGraceEpochs = 26; // ~6 months

    // ================================
    // EVENTS
    // ================================

    event RewardsNotified(uint256 indexed epoch, address indexed vault, address indexed token, uint256 amount);
    event RewardTokenSet(address indexed vault, address indexed token);
    event RewardTokenRecovered(address indexed vault, address indexed oldToken, address indexed newToken);
    event Claimed(uint256 indexed epoch, address indexed vault, address indexed user, address token, uint256 amount);
    event ProtocolTreasuryUpdated(address indexed oldTreasury, address indexed newTreasury);
    event ZeroVoteEpochSwept(
        uint256 indexed epoch, address indexed vault, address indexed token, uint256 amount, address protocolTreasury
    );

    // ================================
    // ERRORS
    // ================================

    error ZeroAddress();
    error ZeroAmount();
    error UnauthorizedNotifier();
    error InvalidVaultRegistration();
    error RewardTokenMismatch();
    error ProtocolTreasuryNotSet();
    error SweepNotAllowedYet();
    error NotZeroVoteEpoch();
    error EpochNotEnded();

    // ================================
    // CONSTRUCTOR
    // ================================

    constructor(address _gaugeVoting, address _registry, address _owner) Ownable(_owner) {
        if (_gaugeVoting == address(0) || _registry == address(0)) revert ZeroAddress();
        gaugeVoting = IVe4626GaugeVotingForRewards(_gaugeVoting);
        registry = IRegistry4626ForVoterRewards(_registry);
    }

    // ================================
    // ADMIN
    // ================================

    function setProtocolTreasury(address _protocolTreasury) external onlyOwner {
        if (_protocolTreasury == address(0)) revert ZeroAddress();
        address old = protocolTreasury;
        protocolTreasury = _protocolTreasury;
        emit ProtocolTreasuryUpdated(old, _protocolTreasury);
    }

    /**
     * @notice Owner recovery path for fixing an incorrect reward token mapping.
     * @dev FIX: G-10 — only affects future epochs; past epoch tokens are stored per-epoch.
     */
    function recoverVaultRewardToken(address vault, address token) external onlyOwner {
        if (vault == address(0) || token == address(0)) revert ZeroAddress();
        address oldToken = vaultRewardToken[vault];
        vaultRewardToken[vault] = token;
        emit RewardTokenRecovered(vault, oldToken, token);
    }

    // ================================
    // NOTIFY (CALLED BY GAUGE CONTROLLERS)
    // ================================

    /**
     * @notice Notify rewards for a vault for the current epoch.
     * @dev Caller must have approved `token` to this contract.
     */
    function notifyRewards(address vault, address token, uint256 amount) external nonReentrant {
        if (vault == address(0) || token == address(0)) revert ZeroAddress();
        if (amount == 0) revert ZeroAmount();

        address creatorToken = registry.getTokenForVault(vault);
        if (creatorToken == address(0)) revert InvalidVaultRegistration();

        address expectedGauge = registry.getGaugeControllerForToken(creatorToken);
        if (expectedGauge == address(0) || msg.sender != expectedGauge) revert UnauthorizedNotifier();

        address existing = vaultRewardToken[vault];
        if (existing == address(0)) {
            vaultRewardToken[vault] = token;
            emit RewardTokenSet(vault, token);
        } else if (existing != token) {
            revert RewardTokenMismatch();
        }

        IERC20(token).safeTransferFrom(msg.sender, address(this), amount);

        // FIX: G-04 — credit rewards to previous (finalized) epoch, not the live epoch
        // This prevents informational asymmetry where large voters know which epoch is well-funded
        uint256 current = gaugeVoting.currentEpoch();
        uint256 epoch = current > 0 ? current - 1 : current;
        epochVaultRewards[epoch][vault] += amount;

        // FIX: G-10 — record reward token per (epoch, vault) so claims use the correct token
        if (epochRewardToken[epoch][vault] == address(0)) {
            epochRewardToken[epoch][vault] = token;
        }

        emit RewardsNotified(epoch, vault, token, amount);
    }

    // ================================
    // SWEEP (OWNER-ONLY)
    // ================================

    /**
     * @notice Sweep rewards for a (epoch, vault) that had 0 votes, after the grace period.
     * @dev Your selected policy:
     *      - sweepGraceEpochs = 4
     *      - sweep only when vault vote weight == 0 for that epoch
     *      - sweep to protocolTreasury
     */
    function sweepZeroVoteEpoch(address vault, uint256 epoch) external onlyOwner nonReentrant returns (uint256 amount) {
        if (vault == address(0)) revert ZeroAddress();

        address treasury = protocolTreasury;
        if (treasury == address(0)) revert ProtocolTreasuryNotSet();

        uint256 current = gaugeVoting.currentEpoch();
        if (epoch + sweepGraceEpochs >= current) revert SweepNotAllowedYet();

        // Only sweep epochs with 0 votes for this vault (no eligible claimants).
        if (gaugeVoting.getVaultWeightAtEpoch(epoch, vault) != 0) revert NotZeroVoteEpoch();

        amount = epochVaultRewards[epoch][vault];
        if (amount == 0) return 0;

        // FIX: L-04 (4626-352) — previously used the global `vaultRewardToken`
        // mapping, which returns the *current* token for the vault. If the
        // reward token was switched after the epoch being swept, this path
        // would transfer the new token instead of the one actually held for
        // that epoch, either swapping-out live rewards or reverting on zero
        // balance. Prefer the per-epoch record stored by
        // `depositReward(epoch, ...)`; fall back to the global only when a
        // pre-migration epoch has no per-epoch record.
        address token = epochRewardToken[epoch][vault];
        if (token == address(0)) token = vaultRewardToken[vault];
        if (token == address(0)) revert ZeroAddress();

        // Effects before interactions
        epochVaultRewards[epoch][vault] = 0;

        IERC20(token).safeTransfer(treasury, amount);

        emit ZeroVoteEpochSwept(epoch, vault, token, amount, treasury);
    }

    // FIX: G-18 — sweep path for unclaimed rewards in non-zero-vote epochs after extended grace
    /// @dev Grace window defaults to ~6 months (`staleSweepGraceEpochs` epochs). Operators
    ///      should verify `previewClaim` totals before sweeping (AUDIT-2026-07-01-M14).
    event StaleEpochSwept(
        uint256 indexed epoch, address indexed vault, address indexed token, uint256 amount, uint256 graceEpochs
    );

    function sweepStaleEpochRewards(address vault, uint256 epoch) external onlyOwner nonReentrant returns (uint256 amount) {
        if (vault == address(0)) revert ZeroAddress();

        address treasury = protocolTreasury;
        if (treasury == address(0)) revert ProtocolTreasuryNotSet();

        uint256 current = gaugeVoting.currentEpoch();
        if (epoch + staleSweepGraceEpochs >= current) revert SweepNotAllowedYet();

        amount = epochVaultRewards[epoch][vault];
        if (amount == 0) return 0;

        // FIX: G-10 — use per-epoch token
        address token = epochRewardToken[epoch][vault];
        if (token == address(0)) {
            token = vaultRewardToken[vault];
        }
        if (token == address(0)) revert ZeroAddress();

        epochVaultRewards[epoch][vault] = 0;
        IERC20(token).safeTransfer(treasury, amount);

        emit StaleEpochSwept(epoch, vault, token, amount, staleSweepGraceEpochs);
    }

    // ================================
    // CLAIM
    // ================================

    function previewClaim(address user, address vault, uint256 epoch) external view returns (uint256 amount) {
        if (user == address(0) || vault == address(0)) return 0;
        // Strict epoch accounting: claims only after the epoch has ended (epoch is finalized).
        if (epoch >= gaugeVoting.currentEpoch()) return 0;
        if (hasClaimed[epoch][vault][user]) return 0;

        uint256 reward = epochVaultRewards[epoch][vault];
        if (reward == 0) return 0;

        uint256 totalWeight = gaugeVoting.getVaultWeightAtEpoch(epoch, vault);
        if (totalWeight == 0) return 0;

        uint256 userWeight = gaugeVoting.getUserVoteWeightAtEpoch(epoch, user, vault);
        if (userWeight == 0) return 0;

        return (reward * userWeight) / totalWeight;
    }

    function claim(address vault, uint256 epoch) external nonReentrant returns (uint256 amount) {
        return _claim(msg.sender, vault, epoch);
    }

    function claimMany(address[] calldata vaults, uint256 epoch) external nonReentrant returns (uint256 totalAmount) {
        for (uint256 i = 0; i < vaults.length; i++) {
            totalAmount += _claim(msg.sender, vaults[i], epoch);
        }
    }

    function _claim(address user, address vault, uint256 epoch) internal returns (uint256 amount) {
        if (vault == address(0) || user == address(0)) revert ZeroAddress();
        // Strict epoch accounting: claims only after the epoch has ended (epoch is finalized).
        if (epoch >= gaugeVoting.currentEpoch()) revert EpochNotEnded();
        if (hasClaimed[epoch][vault][user]) return 0;

        // FIX: G-10 — use per-epoch token, fall back to global mapping for legacy epochs
        address token = epochRewardToken[epoch][vault];
        if (token == address(0)) {
            token = vaultRewardToken[vault];
        }
        if (token == address(0)) {
            hasClaimed[epoch][vault][user] = true;
            return 0;
        }

        uint256 reward = epochVaultRewards[epoch][vault];
        if (reward == 0) {
            hasClaimed[epoch][vault][user] = true;
            return 0;
        }

        uint256 totalWeight = gaugeVoting.getVaultWeightAtEpoch(epoch, vault);
        if (totalWeight == 0) {
            // Nobody voted for this vault this epoch → nobody can claim.
            // Keep rewards in the contract; governance can decide how to handle later.
            hasClaimed[epoch][vault][user] = true;
            return 0;
        }

        uint256 userWeight = gaugeVoting.getUserVoteWeightAtEpoch(epoch, user, vault);
        if (userWeight == 0) {
            hasClaimed[epoch][vault][user] = true;
            return 0;
        }

        amount = (reward * userWeight) / totalWeight;
        hasClaimed[epoch][vault][user] = true;

        if (amount > 0) {
            IERC20(token).safeTransfer(user, amount);
        }

        emit Claimed(epoch, vault, user, token, amount);
    }
}

